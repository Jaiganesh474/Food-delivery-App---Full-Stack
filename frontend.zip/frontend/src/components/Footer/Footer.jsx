import 'react'
import './Footer.css'
import { assets } from '../../assets/assets'

const Footer = () => {
    return (
        <div className='footer' id='footer'>
            <div className="footer-content">
                <div className="footer-content-left">   
                    <img src={assets.logo} alt="" />
                    <h2>ABOUT US</h2>
                    <p>Tomato Food Delivery is your trusted partner for delicious and timely food delivery. We connect you with the best dishes from top chefs, ensuring fresh and flavorful meals at your doorstep. With a commitment to quality and customer satisfaction, we make every meal a delightful experience.</p>
                    <div className="footer-social-icons">
                        <img src={assets.facebook_icon} alt="" />
                        <img src={assets.twitter_icon} alt="" />
                        <img src={assets.linkedin_icon} alt="" />
                    </div>
                </div>
                <div className="footer-content-center">
                    <h2>COMPANY</h2>
                    <ul>
                        <a href='/'>Home</a>
                        <a href='#footer'>About us</a>
                        <a href='/cart'>Delivery</a>
                        <a href='/'>Privacy Policy</a>
                    </ul>
                </div>
                <div className="footer-content-right">
                    <h2>GET IN TOUCH</h2>
                    <ul>
                        <li>+123 456 789 0</li>
                        <li>contact@tomato.com</li>
                    </ul>
                </div>
            </div>
            <hr />
            <p className="footer-copyright">Copyright 2024 © Tomato.com - All Right Reserved</p>

        </div>
    )
}

export default Footer
