import mongoose from "mongoose";

export const connectDB= async()=>{
    await mongoose.connect('mongodb+srv://jaiganeshrio:123454321@cluster0.tljn3.mongodb.net/food-del').then(()=>console.log("DB Connected"));
}